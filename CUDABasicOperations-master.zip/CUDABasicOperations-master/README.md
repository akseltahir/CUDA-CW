# CUDA Parallel Computing

This repository, contains fundamental parallel operations such as Matrix Multiplication, Reduce, Scan and Histogram generation, all under the CUDA architecture. This was initially done as part of the coursework for COM2039. 

## License
[MIT](https://choosealicense.com/licenses/mit/)
